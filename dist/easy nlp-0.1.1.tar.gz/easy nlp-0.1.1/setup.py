from setuptools import setup
setup(name='easy nlp',
version = '0.1.1',
description = "NLP made easy.",
author = "Rajesh Nathani" ,
author_email = "rajeshnathani055@gmail.com",
license = "MIT" ,
install_requires =['spacy==2.2'],
packages = ['easy_nlp'] , zip_safe = False
)